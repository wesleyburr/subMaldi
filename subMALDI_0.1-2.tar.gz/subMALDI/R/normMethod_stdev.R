# -----------------------------------------------------------------------
# Last Updated: June 12, 2020
# Author: Kristen Yeh
# Title: subMALDI: Normalization Method - Standard Deviation of Noise
# -----------------------------------------------------------------------


plotgridSpectra(S, mass_dat = "full_mz", spec1 = "s1", spec2 = "s2",
                spec3 = "s3", spec4 = "s4", spec5 = "s5", spec6 = "s6")


# ------------------------------------
# METHOD: STANDARD DEVIATION OF NOISE
# ------------------------------------

# Find a region of the spectrum with only noise and minimal peaks
    # (Should be same region for all spectra)
# Evaluate standard deviation of intensity in that region for each spec
# Divide intensity of EACH PEAK IN SPEC by its st. dev.


.normMethod_stdev <- function(dat, mass_dat, spec1, spec2, spec3 = NULL,
                              spec4 = NULL, spec5 = NULL, spec6 = NULL){
  
  if(is.null(spec2)){
    
    # One spectrum
    stop("Only one spectrum input. Please enter two spectra for comparison.")}
  
  # ---------------------------------------------------------------------
  # Two spectra
  else{
    intense1 <- dat[[spec1]]
    intense2 <- dat[[spec2]]
  }
}





































