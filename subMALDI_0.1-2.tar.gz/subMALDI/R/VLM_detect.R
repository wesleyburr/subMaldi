# -----------------------------------------------------------------------
# Last Updated: June 9, 2020
# Author: Kristen Yeh
# Title: subMALDI: Virtual Lock Mass Detection
# -----------------------------------------------------------------------


# Probably require package 'datastructures' to get a binary heap

install.packages("datastructures")
library("datastructures")
library("subMALDI")

# Sample dataset
S <- createSpecDF(res = 1e-05, dig = 5)
S <- select(S, full_mz)
S <- transform(S, "s1" = 0, "s2" = 0, "s3" = 0, "s4" = 0, "s5" = 0)

S <- mapSpectrum(dat = aPN_C15, massCol = "mass", intenseCol = "Intensity", 
                 dig = 5, thresh = 1e-05, spec_df = S, colName = "s1")
S <- mapSpectrum(dat = aPN_C18, massCol = "mass", intenseCol = "Intensity", 
                 dig = 5, thresh = 1e-05, spec_df = S, colName = "s2")
S <- mapSpectrum(dat = aPN_C20, massCol = "mass", intenseCol = "Intensity", 
                 dig = 5, thresh = 1e-05, spec_df = S, colName = "s3")
S <- mapSpectrum(dat = aPN_D21, massCol = "mass", intenseCol = "Intensity", 
                 dig = 5, thresh = 1e-05, spec_df = S, colName = "s4")
S <- mapSpectrum(dat = aPN_I20, massCol = "mass", intenseCol = "Intensity", 
                 dig = 5, thresh = 1e-05, spec_df = S, colName = "s5")

S <- rmveEmpty(S)

# Given this set of spectra each peak should be identified by (o,p)
S <- gather(S, key = "Spectra", value = "Intensity", s1, s2, s3, s4, s5, factor_key = TRUE)
# o = index of spectrum of origin ("Spectra")
# p = index of peaks in each spectrum 

# Remove 0 values so no empty peaks are indexed
S <- filter(S, Intensity != 0)

# Add an index column for the peaks in each spectrum
S0 <- S %>% group_by(Spectra) %>% mutate(id = row_number())
# p = id column in S

# Begin by initializing a binary heap (H of m peaks)
H <- binomial_heap("numeric")
keys <- 
values <- 

# Active Sequence
# A = doubly linked list with Boolean-valued vector B of dimension m
# m = number of spectra in set S

  
# -----------------------------------------------------------------------


# ---------------
# VLM Parameters
# ---------------

# 1. P contains exactly one peak from each spectrum in S.
# 2. Average of the m/z values in P is equal to v.
# 3. Every peak in P has a m/z value in the interval [v(1-w), v(1+w)]
# 4. No other peak in S has a m/z value within the interval.
# 5. Every peak P has an intensity above a certain threshold.
  

  
  
# --------------------------------
# Methods required by A.isValid()
# --------------------------------


# L.front()
# returns a copy of the peak at the beginning of L (smallest m/z)

# L.back()
# returns a copy of of the peak at the end of L

# L.push_back(o,p)
# inserts the peak (o,p) at the end of L

# L.size()
# returns the number of peaks in L

# L.pop_front()
# removes the peak at the beginning of L


# -------------------
# A.isValid() METHOD
# -------------------


# Input = the heap containing m peaks
# Output = TRUE, if and only if the set of peaks in A is a valid VLM


























