library(testthat)
library(subMALDI)

test_check("subMALDI")
